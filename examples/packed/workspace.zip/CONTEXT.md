Illustrative budget review
Global context/variables: state/global.gst; unresolved values remain null.
