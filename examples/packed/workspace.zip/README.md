# ICM workspace
Source-preserving authoring snapshot. Conditions are unevaluated.
