{
  "constraints": {
    "execution": "unsupported",
    "source_text": "verbatim"
  },
  "continuity": {
    "placeholder": "0,0"
  },
  "external": {
    "current": {
      "sessions": [
        {
          "captured_at": "2026-10-31",
          "id": "example-capture",
          "lines": [
            {
              "text": "Budget cap is 42 units."
            },
            {
              "text": "An unresolved owner needs human review."
            }
          ],
          "markers": [
            {
              "end": 0,
              "note": "Keep exact cap",
              "start": 0
            },
            {
              "end": 1,
              "note": "Owner is unknown",
              "start": 1
            }
          ],
          "source": "authored example (not AI output)",
          "title": "Illustrative budget source"
        }
      ]
    },
    "prior": {}
  },
  "gst_version": "1.0",
  "intent": "Preserve and organize user-reviewed source markers",
  "internal": {
    "current": {
      "global": {
        "context": "Illustrative budget review",
        "gestalt": "Review budget without inventing an owner",
        "variables": {
          "cap": 42,
          "owner": null
        }
      },
      "markers": [
        {
          "capture_id": "example-capture",
          "captured_at": "2026-10-31",
          "end": 0,
          "id": "M1",
          "n": 1,
          "note": "Keep exact cap",
          "si": 0,
          "source": "authored example (not AI output)",
          "start": 0,
          "text": "Budget cap is 42 units.",
          "title": "Illustrative budget source"
        },
        {
          "capture_id": "example-capture",
          "captured_at": "2026-10-31",
          "end": 1,
          "id": "M2",
          "n": 2,
          "note": "Owner is unknown",
          "si": 0,
          "source": "authored example (not AI output)",
          "start": 1,
          "text": "An unresolved owner needs human review.",
          "title": "Illustrative budget source"
        }
      ]
    },
    "prior": {}
  },
  "outcome_expectation": "Human-reviewed authored workspace; conditions unevaluated",
  "state_id": "texport.state.452d69691f72435fbc40940cc88a5c70"
}
